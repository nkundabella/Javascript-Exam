const express = require('express');
const app = express();
const students = [];
const port = 3000;

// a. Creation of a student class with name and grade properties
class Student {
    constructor(name, grade) {
        this.name = name;
        this.grade = grade;
    }
    //A method getDetails to return strings
    getDetails() {
        return `Name: ${this.name}, Grade: ${this.grade}`;
    }
}

//b. The middleware to parse JSON requests (built in)
app.use(express.json());

//c. Creation of a POST route to add a new student
app.post('/students', (req, res) => {
   const {name, grade} = req.body;
    
    if (!name || !grade) {
        return res.status(400).json({ error: 'Name & Grade are required!' });
    }

    const student = new Student(name, grade);
    students.push(student);
    
    res.status(201).json({ message: 'Student Just got added successfully!🥳', student: student.getDetails() });
});

//d. Creation of a GET route to return all students
app.get('/students', (req, res) => {
    const studentDetails = students.map(student => student.getDetails());
    res.json({ students: studentDetails });
});

//Our general server
app.listen(port, () => {
    console.log(`Server is running on http://localhost:${port}`);
}); 